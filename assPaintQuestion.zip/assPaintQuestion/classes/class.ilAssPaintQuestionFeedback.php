<?php

require_once 'Modules/TestQuestionPool/classes/feedback/class.ilAssSingleOptionQuestionFeedback.php';

/**
 * Cas Question object
 *
 * @author Fred Neumann <fred.neumann@ili.fau.de>
 * @author Jesus Copado <jesus.copado@ili.fau.de>
 * @version $Id$
 *
 */

class ilAssPaintQuestionFeedback extends ilAssSingleOptionQuestionFeedback
{
    
}
