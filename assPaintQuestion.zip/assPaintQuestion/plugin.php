<?php
 
// alphanumerical ID of the plugin; never change this
$id = "assPaintQuestion";
 
// code version; must be changed for all code changes
$version = "1.1.4";
 
// ilias min and max version; must always reflect the versions that should
// run with the plugin
$ilias_min_version = "4.4.0";
$ilias_max_version = "4.4.999";

//...-09/2014:
//$responsible = "Yves Annanias";
//$responsible_mail = "yves.annanias@llz.uni-halle.de";

//10/2014-...
$responsible = "Christoph Jobst";
$responsible_mail = "christoph.jobst@llz.uni-halle.de";

?>
